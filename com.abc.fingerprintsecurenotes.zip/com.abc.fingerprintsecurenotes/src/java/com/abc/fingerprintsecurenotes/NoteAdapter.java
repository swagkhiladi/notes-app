package com.abc.fingerprintsecurenotes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class NoteAdapter extends ArrayAdapter<Note> {
    public static final int WRAP_CONTENT_LENGTH = 50;

    public NoteAdapter(Context context, int i, List<Note> list) {
        super(context, i, list);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.view_note_item, null);
        }
        Note note = (Note) getItem(i);
        if (note != null) {
            TextView textView = (TextView) view.findViewById(R.id.list_note_date);
            TextView textView2 = (TextView) view.findViewById(R.id.list_note_content_preview);
            ((TextView) view.findViewById(R.id.list_note_title)).setText(note.getTitle());
            textView.setText(note.getDateTimeFormatted(getContext()));
            int indexOf = note.getContent().indexOf(10);
            if (note.getContent().length() > 50 || indexOf < 50) {
                if (indexOf >= 50) {
                    indexOf = 50;
                }
                if (indexOf > 0) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(note.getContent().substring(0, indexOf));
                    stringBuilder.append("...");
                    textView2.setText(stringBuilder.toString());
                } else {
                    textView2.setText(note.getContent());
                }
            } else {
                textView2.setText(note.getContent());
            }
        }
        return view;
    }
}
