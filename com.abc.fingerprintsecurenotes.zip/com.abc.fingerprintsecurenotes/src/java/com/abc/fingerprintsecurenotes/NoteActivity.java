package com.abc.fingerprintsecurenotes;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class NoteActivity extends AppCompatActivity {
    private EditText mEtContent;
    private EditText mEtTitle;
    private String mFileName;
    private boolean mIsViewingOrUpdating;
    private Note mLoadedNote = null;
    private long mNoteCreationTime;

    /* Access modifiers changed, original: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_note);
        this.mEtTitle = (EditText) findViewById(R.id.note_et_title);
        this.mEtContent = (EditText) findViewById(R.id.note_et_content);
        this.mFileName = getIntent().getStringExtra(Utilities.EXTRAS_NOTE_FILENAME);
        if (this.mFileName == null || this.mFileName.isEmpty() || !this.mFileName.endsWith(Utilities.FILE_EXTENSION)) {
            this.mNoteCreationTime = System.currentTimeMillis();
            this.mIsViewingOrUpdating = false;
            return;
        }
        this.mLoadedNote = Utilities.getNoteByFileName(getApplicationContext(), this.mFileName);
        if (this.mLoadedNote != null) {
            this.mEtTitle.setText(this.mLoadedNote.getTitle());
            this.mEtContent.setText(this.mLoadedNote.getContent());
            this.mNoteCreationTime = this.mLoadedNote.getDateTime();
            this.mIsViewingOrUpdating = true;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        if (this.mIsViewingOrUpdating) {
            getMenuInflater().inflate(R.menu.menu_note_view, menu);
        } else {
            getMenuInflater().inflate(R.menu.menu_note_add, menu);
        }
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.action_cancel) {
            actionCancel();
        } else if (itemId == R.id.action_delete) {
            actionDelete();
        } else if (itemId == R.id.action_save_note || itemId == R.id.action_update) {
            validateAndSaveNote();
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onBackPressed() {
        actionCancel();
    }

    private void actionDelete() {
        new Builder(this).setTitle("delete note").setMessage("really delete the note?").setPositiveButton("YES", new OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                NoteActivity noteActivity;
                StringBuilder stringBuilder;
                if (NoteActivity.this.mLoadedNote == null || !Utilities.deleteFile(NoteActivity.this.getApplicationContext(), NoteActivity.this.mFileName)) {
                    noteActivity = NoteActivity.this;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append("can not delete the note '");
                    stringBuilder.append(NoteActivity.this.mLoadedNote.getTitle());
                    stringBuilder.append("'");
                    Toast.makeText(noteActivity, stringBuilder.toString(), 0).show();
                } else {
                    noteActivity = NoteActivity.this;
                    stringBuilder = new StringBuilder();
                    stringBuilder.append(NoteActivity.this.mLoadedNote.getTitle());
                    stringBuilder.append(" is deleted");
                    Toast.makeText(noteActivity, stringBuilder.toString(), 0).show();
                }
                NoteActivity.this.startActivity(new Intent(NoteActivity.this, MainActivity.class));
                NoteActivity.this.finish();
            }
        }).setNegativeButton("NO", null).show();
    }

    private void actionCancel() {
        if (checkNoteAltred()) {
            new Builder(this).setTitle("discard changes...").setMessage("are you sure you do not want to save changes to this note?").setPositiveButton("YES", new OnClickListener() {
                public void onClick(DialogInterface dialogInterface, int i) {
                    NoteActivity.this.startActivity(new Intent(NoteActivity.this, MainActivity.class));
                    NoteActivity.this.finish();
                }
            }).setNegativeButton("NO", null).show();
            return;
        }
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private boolean checkNoteAltred() {
        boolean z = false;
        if (this.mIsViewingOrUpdating) {
            if (!(this.mLoadedNote == null || (this.mEtTitle.getText().toString().equalsIgnoreCase(this.mLoadedNote.getTitle()) && this.mEtContent.getText().toString().equalsIgnoreCase(this.mLoadedNote.getContent())))) {
                z = true;
            }
            return z;
        }
        if (!(this.mEtTitle.getText().toString().isEmpty() && this.mEtContent.getText().toString().isEmpty())) {
            z = true;
        }
        return z;
    }

    private void validateAndSaveNote() {
        String obj = this.mEtTitle.getText().toString();
        String obj2 = this.mEtContent.getText().toString();
        if (obj.isEmpty()) {
            Toast.makeText(this, "please enter a title!", 0).show();
        } else if (obj2.isEmpty()) {
            Toast.makeText(this, "please enter a content for your note!", 0).show();
        } else {
            if (this.mLoadedNote != null) {
                this.mNoteCreationTime = this.mLoadedNote.getDateTime();
            } else {
                this.mNoteCreationTime = System.currentTimeMillis();
            }
            if (Utilities.saveNote(this, new Note(this.mNoteCreationTime, obj, obj2))) {
                Toast.makeText(this, "note has been saved", 0).show();
            } else {
                Toast.makeText(this, "can not save the note. make sure you have enough space on your device", 0).show();
            }
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }
}
