package com.abc.fingerprintsecurenotes;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.AuthenticationCallback;
import android.hardware.fingerprint.FingerprintManager.AuthenticationResult;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.os.CancellationSignal;
import android.support.v4.content.ContextCompat;
import android.widget.ImageView;
import android.widget.TextView;

@TargetApi(23)
public class FingerprintHandler extends AuthenticationCallback {
    private Context context;

    public FingerprintHandler(Context context) {
        this.context = context;
    }

    public void startauth(FingerprintManager fingerprintManager, CryptoObject cryptoObject) {
        fingerprintManager.authenticate(cryptoObject, new CancellationSignal(), 0, this, null);
    }

    public void onAuthenticationError(int i, CharSequence charSequence) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("There Was An Authentication Error. ");
        stringBuilder.append(charSequence);
        update(stringBuilder.toString(), false);
    }

    public void onAuthenticationFailed() {
        update("Authentication Failed. ", false);
    }

    public void onAuthenticationHelp(int i, CharSequence charSequence) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error. ");
        stringBuilder.append(charSequence);
        update(stringBuilder.toString(), false);
    }

    public void onAuthenticationSucceeded(AuthenticationResult authenticationResult) {
        update("You Can Now Access The Notes. ", true);
    }

    private void update(String str, boolean z) {
        TextView textView = (TextView) ((Activity) this.context).findViewById(R.id.paraLabel);
        ImageView imageView = (ImageView) ((Activity) this.context).findViewById(R.id.fingerprintImage);
        textView.setText(str);
        if (z) {
            textView.setTextColor(ContextCompat.getColor(this.context, R.color.colorBlue));
            imageView.setImageResource(R.mipmap.action_done);
            return;
        }
        textView.setTextColor(ContextCompat.getColor(this.context, R.color.colorRed));
    }
}
