package com.abc.fingerprintsecurenotes;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.Calendar;

public class AlarmActivity extends AppCompatActivity {
    static final int RQS_1 = 1;
    Button buttonSetAlarm;
    DatePicker pickerDate;
    TimePicker pickerTime;

    /* Access modifiers changed, original: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_alarm);
        this.pickerDate = (DatePicker) findViewById(R.id.pickerdate);
        this.pickerTime = (TimePicker) findViewById(R.id.pickertime);
        Calendar instance = Calendar.getInstance();
        this.pickerDate.init(instance.get(1), instance.get(2), instance.get(5), null);
        this.pickerTime.setHour(instance.get(11));
        this.pickerTime.setMinute(instance.get(12));
        this.buttonSetAlarm = (Button) findViewById(R.id.setalarm);
        this.buttonSetAlarm.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                Calendar instance = Calendar.getInstance();
                Calendar instance2 = Calendar.getInstance();
                instance2.set(AlarmActivity.this.pickerDate.getYear(), AlarmActivity.this.pickerDate.getMonth(), AlarmActivity.this.pickerDate.getDayOfMonth(), AlarmActivity.this.pickerTime.getHour(), AlarmActivity.this.pickerTime.getMinute(), 0);
                if (instance2.compareTo(instance) <= 0) {
                    Toast.makeText(AlarmActivity.this.getApplicationContext(), "Invalid Date/Time", 1).show();
                } else {
                    AlarmActivity.this.setAlarm(instance2);
                }
            }
        });
    }

    /* Access modifiers changed, original: protected */
    public void onDestroy() {
        super.onDestroy();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void setAlarm(Calendar calendar) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Reminder Notification is set@ ");
        stringBuilder.append(calendar.getTime());
        Toast.makeText(this, stringBuilder.toString(), 1).show();
        ((AlarmManager) getSystemService("alarm")).set(0, calendar.getTimeInMillis(), PendingIntent.getBroadcast(getBaseContext(), 1, new Intent(getBaseContext(), AlarmReceiver.class), 0));
    }
}
