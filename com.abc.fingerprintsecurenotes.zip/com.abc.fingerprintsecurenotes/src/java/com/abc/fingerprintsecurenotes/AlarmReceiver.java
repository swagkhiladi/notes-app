package com.abc.fingerprintsecurenotes;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION;
import android.support.v4.app.NotificationCompat.Builder;
import android.support.v4.app.NotificationManagerCompat;

public class AlarmReceiver extends BroadcastReceiver {
    public final String CHANNEL_ID = "personal_notifications";
    public final int NOTIFICATION_ID = 1;
    Builder notification;

    public void onReceive(Context context, Intent intent) {
        createnotificationchannel(context);
        this.notification = new Builder(context, "personal_notifications");
        this.notification.setSmallIcon(R.mipmap.ic_launcher);
        this.notification.setTicker("Reminder from your FingerPrint Secure Notes app");
        this.notification.setAutoCancel(true);
        this.notification.setContentTitle("FingerPrint Secure Notes");
        this.notification.setContentText("Reminder!!");
        this.notification.setPriority(0);
        this.notification.setContentIntent(PendingIntent.getActivity(context, 0, new Intent(context, MainActivity.class), 134217728));
        NotificationManagerCompat.from(context).notify(1, this.notification.build());
    }

    public void createnotificationchannel(Context context) {
        if (VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel("personal_notifications", "Personal Notifications", 3);
            notificationChannel.setDescription("Include all personal notifications");
            ((NotificationManager) context.getSystemService("notification")).createNotificationChannel(notificationChannel);
        }
    }
}
