package com.abc.fingerprintsecurenotes;

import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.content.Intent;
import android.hardware.fingerprint.FingerprintManager;
import android.hardware.fingerprint.FingerprintManager.CryptoObject;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec.Builder;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class Home extends AppCompatActivity {
    private String KEY_NAME = "AndroidKey";
    private Cipher cipher;
    private FingerprintManager fingerprintManager;
    private KeyStore keyStore;
    private KeyguardManager keyguardManager;
    private ImageView mFingerprintImage;
    private TextView mHeadingLabel;
    private TextView mParaLabel;

    /* Access modifiers changed, original: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_home);
        this.mHeadingLabel = (TextView) findViewById(R.id.headingLabel);
        this.mFingerprintImage = (ImageView) findViewById(R.id.fingerprintImage);
        this.mParaLabel = (TextView) findViewById(R.id.paraLabel);
        this.mParaLabel.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable editable) {
            }

            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                if (charSequence.toString().equals("You Can Now Access The Notes. ")) {
                    Home.this.startActivity(new Intent(Home.this, MainActivity.class));
                }
            }
        });
        if (VERSION.SDK_INT >= 23) {
            this.fingerprintManager = (FingerprintManager) getSystemService("fingerprint");
            this.keyguardManager = (KeyguardManager) getSystemService("keyguard");
            if (!this.fingerprintManager.isHardwareDetected()) {
                this.mParaLabel.setText("FingerPrint Scanner Not Detected in Device");
            } else if (ContextCompat.checkSelfPermission(this, "android.permission.USE_FINGERPRINT") != 0) {
                this.mParaLabel.setText("Permission Not Granted to Use FingerPrint Scanner");
            } else if (!this.keyguardManager.isKeyguardSecure()) {
                this.mParaLabel.setText("Lock Screen Security Not Enabled in Settings");
            } else if (this.fingerprintManager.hasEnrolledFingerprints()) {
                this.mParaLabel.setText("Place Your Finger on Sensor to Access The App ");
                generateKey();
                if (cipherInit()) {
                    new FingerprintHandler(this).startauth(this.fingerprintManager, new CryptoObject(this.cipher));
                }
            } else {
                this.mParaLabel.setText("Register At Least One FingerPrint In Settings");
            }
        }
    }

    /* Access modifiers changed, original: protected */
    public void onStop() {
        super.onStop();
        finish();
    }

    @TargetApi(23)
    private void generateKey() {
        try {
            this.keyStore = KeyStore.getInstance("AndroidKeyStore");
            KeyGenerator instance = KeyGenerator.getInstance("AES", "AndroidKeyStore");
            this.keyStore.load(null);
            instance.init(new Builder(this.KEY_NAME, 3).setBlockModes(new String[]{"CBC"}).setUserAuthenticationRequired(true).setEncryptionPaddings(new String[]{"PKCS7Padding"}).build());
            instance.generateKey();
        } catch (IOException | InvalidAlgorithmParameterException | KeyStoreException | NoSuchAlgorithmException | NoSuchProviderException | CertificateException e) {
            e.printStackTrace();
        }
    }

    @TargetApi(23)
    public boolean cipherInit() {
        try {
            this.cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            try {
                this.keyStore.load(null);
                this.cipher.init(1, (SecretKey) this.keyStore.getKey(this.KEY_NAME, null));
                return true;
            } catch (KeyPermanentlyInvalidatedException unused) {
                return false;
            } catch (IOException | InvalidKeyException | KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException | CertificateException e) {
                throw new RuntimeException("Failed to init Cipher", e);
            }
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e2) {
            throw new RuntimeException("Failed to get Cipher", e2);
        }
    }
}
