package com.abc.fingerprintsecurenotes;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Utilities {
    public static final String EXTRAS_NOTE_FILENAME = "EXTRAS_NOTE_FILENAME";
    public static final String FILE_EXTENSION = ".bin";

    public static boolean saveNote(Context context, Note note) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(String.valueOf(note.getDateTime()));
        stringBuilder.append(FILE_EXTENSION);
        try {
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(context.openFileOutput(stringBuilder.toString(), 0));
            objectOutputStream.writeObject(note);
            objectOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    static ArrayList<Note> getAllSavedNotes(Context context) {
        ArrayList arrayList = new ArrayList();
        File filesDir = context.getFilesDir();
        ArrayList arrayList2 = new ArrayList();
        int i = 0;
        for (String str : filesDir.list()) {
            if (str.endsWith(FILE_EXTENSION)) {
                arrayList2.add(str);
            }
        }
        while (i < arrayList2.size()) {
            try {
                FileInputStream openFileInput = context.openFileInput((String) arrayList2.get(i));
                ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
                arrayList.add((Note) objectInputStream.readObject());
                openFileInput.close();
                objectInputStream.close();
                i++;
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
                return null;
            }
        }
        return arrayList;
    }

    public static Note getNoteByFileName(Context context, String str) {
        File file = new File(context.getFilesDir(), str);
        if (!file.exists() || file.isDirectory()) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("File exist = ");
        stringBuilder.append(str);
        Log.v("UTILITIES", stringBuilder.toString());
        try {
            FileInputStream openFileInput = context.openFileInput(str);
            ObjectInputStream objectInputStream = new ObjectInputStream(openFileInput);
            Note note = (Note) objectInputStream.readObject();
            openFileInput.close();
            objectInputStream.close();
            return note;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean deleteFile(Context context, String str) {
        File file = new File(context.getFilesDir(), str);
        return (!file.exists() || file.isDirectory()) ? false : file.delete();
    }
}
