package com.abc.fingerprintsecurenotes;

import android.content.Context;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Note implements Serializable {
    private String mContent;
    private long mDateTime;
    private String mTitle;

    public Note(long j, String str, String str2) {
        this.mDateTime = j;
        this.mTitle = str;
        this.mContent = str2;
    }

    public void setDateTime(long j) {
        this.mDateTime = j;
    }

    public void setTitle(String str) {
        this.mTitle = str;
    }

    public void setContent(String str) {
        this.mContent = str;
    }

    public long getDateTime() {
        return this.mDateTime;
    }

    public String getDateTimeFormatted(Context context) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", context.getResources().getConfiguration().locale);
        simpleDateFormat.setTimeZone(TimeZone.getDefault());
        return simpleDateFormat.format(new Date(this.mDateTime));
    }

    public String getTitle() {
        return this.mTitle;
    }

    public String getContent() {
        return this.mContent;
    }
}
