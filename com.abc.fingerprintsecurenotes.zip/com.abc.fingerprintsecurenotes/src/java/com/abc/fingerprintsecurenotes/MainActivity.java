package com.abc.fingerprintsecurenotes;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {
    private ListView mListNotes;

    /* Access modifiers changed, original: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        this.mListNotes = (ListView) findViewById(R.id.main_listview);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main_activity, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.action_create) {
            startActivity(new Intent(this, NoteActivity.class));
        } else if (itemId == R.id.action_notification) {
            startActivity(new Intent(this, AlarmActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }

    /* Access modifiers changed, original: protected */
    public void onResume() {
        super.onResume();
        this.mListNotes.setAdapter(null);
        ArrayList allSavedNotes = Utilities.getAllSavedNotes(getApplicationContext());
        Collections.sort(allSavedNotes, new Comparator<Note>() {
            public int compare(Note note, Note note2) {
                return note.getDateTime() > note2.getDateTime() ? -1 : 1;
            }
        });
        if (allSavedNotes == null || allSavedNotes.size() <= 0) {
            Toast.makeText(getApplicationContext(), "you have no saved notes!\ncreate some new notes :)", 0).show();
            return;
        }
        this.mListNotes.setAdapter(new NoteAdapter(this, R.layout.view_note_item, allSavedNotes));
        this.mListNotes.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(((Note) MainActivity.this.mListNotes.getItemAtPosition(i)).getDateTime());
                stringBuilder.append(Utilities.FILE_EXTENSION);
                String stringBuilder2 = stringBuilder.toString();
                Intent intent = new Intent(MainActivity.this.getApplicationContext(), NoteActivity.class);
                intent.putExtra(Utilities.EXTRAS_NOTE_FILENAME, stringBuilder2);
                MainActivity.this.startActivity(intent);
            }
        });
    }

    /* Access modifiers changed, original: protected */
    public void onStop() {
        super.onStop();
        finish();
    }
}
